#ifndef GHOST_H
#define GHOST_H
#include "utility.h"
#include "game.h"
// <Forward Declaration>
// forward declarations can be useful when you need to have looping struct declarations,
// but you want to (should) prevent mutually include dependency.
// Only applicable when you only need the declaration but no need the definition in you sturct,
// which means that you only used the struct as pointer(no access to struct data), param, return type in this file.
// If you have to access the data in struct ex. `A->data`, 
// you should include the corresponding header file for its definition.
// Advance reading : https://stackoverflow.com/questions/18658438/what-is-forward-declaration-and-the-difference-between-typedef-struct-x-and

typedef struct Pacman Pacman;
typedef struct Map Map;
typedef struct Submap Submap;

typedef enum {
	BLOCKED,						 // stay inside the ghost room
	GO_OUT,							 // going out the ghost room
	FREEDOM,					     // free at the map
	GO_IN,							 // going back to the ghost room 
	FLEE							 // pacman powered up
} GhostStatus;

typedef enum {
	Inky = 0,
	Pinky,
	Clyde,
	Blinky,
} GhostType;


typedef struct Ghost{
	object objData;
	bitmapdata imgdata;
	script_func_ptr move_script;
	int speed;
	int64_t go_in_time;
	GhostType typeFlag;
	GhostStatus status;
	ALLEGRO_BITMAP* move_sprite;
	ALLEGRO_BITMAP* flee_sprite;
	ALLEGRO_BITMAP* dead_sprite;
    bool drawn;
    bool shown;
    bool stop;
    int countdown;
} Ghost;

Ghost* ghost_create(int flag, Pair_IntInt position);
void ghost_destroy(Ghost* ghost);
void ghost_draw(Ghost* ghost, Submap* view, Submap* submap);
void ghost_NextMove(Ghost* ghost, Directions next);
void printGhostStatus(GhostStatus);
bool ghost_movable(const Ghost* ghost, const Map* M, Directions targetDirec, bool room);
/* check if the direction is ok to move_script in; if room = true, then room will be treat as not able to move_script in */


void ghost_toggle_FLEE(Ghost* ghosts, bool setFLEE);
void ghost_collided(Ghost* ghost);
void ghost_move_script_random(Ghost* ghost, Map* M, Pacman* pacman);
void ghost_move_script_shortest_path(Ghost* ghost, Map* M, Pacman* pacman);

#endif
