#ifndef SCENE_AFTER_GAME_H
#define SCENE_AFTER_GAME_H
#include "game.h"
#include "shared.h"
Scene scene_after_game_create();
#endif
